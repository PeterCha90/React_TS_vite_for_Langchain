// src/App.js
import '@/App.css'

function App() {
  return (
    <div className="App">
      <div
        className="App-header"
        style={{
          position: 'absolute',
          left: '45%'
        }}>
        🛫 GO FOR IT! 🙌✨
      </div>
    </div>
  )
}

export default App
